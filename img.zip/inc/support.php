<?php 
// Register Custom Post Type
/*
function font_service_type() {

	$labels = array(
		'name'                  => _x( 'Font Service', 'Post Type General Name', 'font_service' ),
		'singular_name'         => _x( 'Font Service', 'Post Type Singular Name', 'font_service' ),
		'menu_name'             => __( 'Font services', 'font_service' ),
		'name_admin_bar'        => __( 'Font Service', 'font_service' ),
		'archives'              => __( 'Item Archives', 'font_service' ),
		'attributes'            => __( 'Item Attributes', 'font_service' ),
		'parent_item_colon'     => __( 'Parent Item:', 'font_service' ),
		'all_items'             => __( 'All Items', 'font_service' ),
		'add_new_item'          => __( 'Add New Item', 'font_service' ),
		'add_new'               => __( 'Add New', 'font_service' ),
		'new_item'              => __( 'New Item', 'font_service' ),
		'edit_item'             => __( 'Edit Item', 'font_service' ),
		'update_item'           => __( 'Update Item', 'font_service' ),
		'view_item'             => __( 'View Item', 'font_service' ),
		'view_items'            => __( 'View Items', 'font_service' ),
		'search_items'          => __( 'Search Item', 'font_service' ),
		'not_found'             => __( 'Not found', 'font_service' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'font_service' ),
		'featured_image'        => __( 'Featured Image', 'font_service' ),
		'set_featured_image'    => __( 'Set featured image', 'font_service' ),
		'remove_featured_image' => __( 'Remove featured image', 'font_service' ),
		'use_featured_image'    => __( 'Use as featured image', 'font_service' ),
		'insert_into_item'      => __( 'Insert into item', 'font_service' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'font_service' ),
		'items_list'            => __( 'Items list', 'font_service' ),
		'items_list_navigation' => __( 'Items list navigation', 'font_service' ),
		'filter_items_list'     => __( 'Filter items list', 'font_service' ),
	);
	$args = array(
		'label'                 => __( 'Font Service', 'font_service' ),
		'description'           => __( 'Font Service Description', 'font_service' ),
		'labels'                => $labels,
		'supports'              => array( ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'				=> 'dashicons-welcome-view-site',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'rewrite'           	=> array('slug'=>'type'),		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'service_post_type', $args );

}
add_action( 'init', 'font_service_type', 0 );
*/

// Garments & Accessories Register Custom Post Type
function blog() {

	$labels = array(
		'name'                  => _x( 'Blog', 'Post Type General Name', 'blog' ),
		'singular_name'         => _x( 'Blog', 'Post Type Singular Name', 'blog' ),
		'menu_name'             => __( 'Blog', 'blog' ),
		'name_admin_bar'        => __( 'Blog', 'blog' ),
		'archives'              => __( 'Item Archives', 'blog' ),
		'attributes'            => __( 'Item Attributes', 'blog' ),
		'parent_item_colon'     => __( 'Parent Item:', 'blog' ),
		'all_items'             => __( 'All Items', 'blog' ),
		'add_new_item'          => __( 'Add New Item', 'blog' ),
		'add_new'               => __( 'Add New', 'blog' ),
		'new_item'              => __( 'New Item', 'blog' ),
		'edit_item'             => __( 'Edit Item', 'blog' ),
		'update_item'           => __( 'Update Item', 'blog' ),
		'view_item'             => __( 'View Item', 'blog' ),
		'view_items'            => __( 'View Items', 'blog' ),
		'search_items'          => __( 'Search Item', 'blog' ),
		'not_found'             => __( 'Not found', 'blog' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'blog' ),
		'featured_image'        => __( 'Featured Image', 'blog' ),
		'set_featured_image'    => __( 'Set featured image', 'blog' ),
		'remove_featured_image' => __( 'Remove featured image', 'blog' ),
		'use_featured_image'    => __( 'Use as featured image', 'blog' ),
		'insert_into_item'      => __( 'Insert into item', 'blog' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'blog' ),
		'items_list'            => __( 'Items list', 'blog' ),
		'items_list_navigation' => __( 'Items list navigation', 'blog' ),
		'filter_items_list'     => __( 'Filter items list', 'blog' ),
	);
	$args = array(
		'label'                 => __( 'Blog', 'blog' ),
		'description'           => __( 'Blog Description', 'blog' ),
		'labels'                => $labels,
		'supports'              => array('title', 'editor', 'revisions', 'author', 'thumbnail','comments' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'				=> 'dashicons-tickets-alt',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'rewrite'           	=> array('slug'=>'blog'),		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'blog', $args );

}
add_action( 'init', 'blog', 0 );


// Our Business Register Custom Post Type
/*
function our_business() {

	$labels = array(
		'name'                  => _x( 'Our Business', 'Post Type General Name', 'our_business' ),
		'singular_name'         => _x( 'Our Business', 'Post Type Singular Name', 'our_business' ),
		'menu_name'             => __( 'Our Business', 'our_business' ),
		'name_admin_bar'        => __( 'Our Business', 'our_business' ),
		'archives'              => __( 'Item Archives', 'our_business' ),
		'attributes'            => __( 'Item Attributes', 'our_business' ),
		'parent_item_colon'     => __( 'Parent Item:', 'our_business' ),
		'all_items'             => __( 'All Items', 'our_business' ),
		'add_new_item'          => __( 'Add New Item', 'our_business' ),
		'add_new'               => __( 'Add New', 'our_business' ),
		'new_item'              => __( 'New Item', 'our_business' ),
		'edit_item'             => __( 'Edit Item', 'our_business' ),
		'update_item'           => __( 'Update Item', 'our_business' ),
		'view_item'             => __( 'View Item', 'our_business' ),
		'view_items'            => __( 'View Items', 'our_business' ),
		'search_items'          => __( 'Search Item', 'our_business' ),
		'not_found'             => __( 'Not found', 'our_business' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'our_business' ),
		'featured_image'        => __( 'Featured Image', 'our_business' ),
		'set_featured_image'    => __( 'Set featured image', 'our_business' ),
		'remove_featured_image' => __( 'Remove featured image', 'our_business' ),
		'use_featured_image'    => __( 'Use as featured image', 'our_business' ),
		'insert_into_item'      => __( 'Insert into item', 'our_business' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'our_business' ),
		'items_list'            => __( 'Items list', 'our_business' ),
		'items_list_navigation' => __( 'Items list navigation', 'our_business' ),
		'filter_items_list'     => __( 'Filter items list', 'our_business' ),
	);
	$args = array(
		'label'                 => __( 'Our Business', 'our_business' ),
		'description'           => __( 'Our Business Description', 'our_business' ),
		'labels'                => $labels,
		'supports'              => array( ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'				=> 'dashicons-clipboard',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'our_business', $args );

}
add_action( 'init', 'our_business', 0 );


*/

// hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'create_portfolio_taxonomy', 0 );

// create two taxonomies, genres and writers for the post type "portfolio"
function create_portfolio_taxonomy() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Portfolios', 'taxonomy general Portfolio' ),
		'singular_name'     => _x( 'Portfolio', 'taxonomy singular Portfolio' ),
		'search_items'      => __( 'Search Portfolios' ),
		'all_items'         => __( 'All Portfolios' ),
		'parent_item'       => __( 'Parent Portfolio' ),
		'parent_item_colon' => __( 'Parent Portfolio:' ),
		'edit_item'         => __( 'Edit Portfolio' ),
		'update_item'       => __( 'Update Portfolio' ),
		'add_new_item'      => __( 'Add New Portfolio' ),
		'new_item_name'     => __( 'New Portfolio Name' ),
		'menu_name'         => __( 'Portfolio' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'portfolio' ),
	);

	


	register_taxonomy( 'portfolio', 'post', $args );
}





//Samsun Option code

if ( ! function_exists( 'ot_register_theme_options_page' ) ) {

  function ot_register_theme_options_page() {
  
    /* get the settings array */
    $get_settings = get_option( ot_settings_id() );
    
    /* sections array */
    $sections = isset( $get_settings['sections'] ) ? $get_settings['sections'] : array();
    
    /* settings array */
    $settings = isset( $get_settings['settings'] ) ? $get_settings['settings'] : array();
    
    /* contexual_help array */
    $contextual_help = isset( $get_settings['contextual_help'] ) ? $get_settings['contextual_help'] : array();
    
    /* build the Theme Options */
    if ( function_exists( 'ot_register_settings' ) && OT_USE_THEME_OPTIONS ) {
      
      ot_register_settings( array(
          array(
            'id'                  => ot_options_id(),
            'pages'               => array( 
              array(
                'id'              => 'ot_theme_options',
                'parent_slug'     => apply_filters( 'ot_theme_options_parent_slug', '' ),
                'page_title'      => apply_filters( 'ot_theme_options_page_title', __( 'Samsun Options', 'option-tree' ) ),
                'menu_title'      => apply_filters( 'ot_theme_options_menu_title', __( 'Samsun Options', 'option-tree' ) ),
                'capability'      => $caps = apply_filters( 'ot_theme_options_capability', 'edit_theme_options' ),
                'menu_slug'       => apply_filters( 'ot_theme_options_menu_slug', 'ot-theme-options' ),
                'icon_url'        => apply_filters( 'ot_theme_options_icon_url', null ),
                'position'        => apply_filters( 'ot_theme_options_position',  __( '5', 'option-tree' ) ),
                'updated_message' => apply_filters( 'ot_theme_options_updated_message', __( 'Samsun Options updated.', 'option-tree' ) ),
                'reset_message'   => apply_filters( 'ot_theme_options_reset_message', __( 'Samsun Options reset.', 'option-tree' ) ),
                'button_text'     => apply_filters( 'ot_theme_options_button_text', __( 'Save Changes', 'option-tree' ) ),
                'contextual_help' => apply_filters( 'ot_theme_options_contextual_help', $contextual_help ),
                'sections'        => apply_filters( 'ot_theme_options_sections', $sections ),
                'settings'        => apply_filters( 'ot_theme_options_settings', $settings )
              )
            )
          )
        ) 
      );
      
      // Filters the options.php to add the minimum user capabilities.
      add_filter( 'option_page_capability_' . ot_options_id(), create_function( '$caps', "return '$caps';" ), 999 );
    
    }
  
  }

}

