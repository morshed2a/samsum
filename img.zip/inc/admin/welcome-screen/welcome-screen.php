<?php
/**
 * Welcome Screen Class
 */
class samsun_Welcome {

	/**
	 * Constructor for the welcome screen
	 */
	public function __construct() {

		/* create dashbord page */
		add_action( 'admin_menu', array( $this, 'samsun_welcome_register_menu' ) );

		/* activation notice */
		add_action( 'load-themes.php', array( $this, 'samsun_activation_admin_notice' ) );

		/* enqueue script and style for welcome screen */
		add_action( 'admin_enqueue_scripts', array( $this, 'samsun_welcome_style_and_scripts' ) );

		/* enqueue script for customizer */
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'samsun_welcome_scripts_for_customizer' ) );

		/* load welcome screen */
		add_action( 'samsun_welcome', array( $this, 'samsun_welcome_getting_started' ), 	    10 );
		add_action( 'samsun_welcome', array( $this, 'samsun_welcome_actions_required' ),        20 );
		add_action( 'samsun_welcome', array( $this, 'samsun_welcome_github' ), 		            40 );
		add_action( 'samsun_welcome', array( $this, 'samsun_welcome_changelog' ), 				50 );

		/* ajax callback for dismissable required actions */
		add_action( 'wp_ajax_samsun_lite_dismiss_required_action', array( $this, 'samsun_dismiss_required_action_callback') );

	}

	/**
	 * Creates the dashboard page
	 * @see  add_theme_page()
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_register_menu() {
		add_theme_page( 'About Samsun', 'About Samsun', 'activate_plugins', 'samsun-welcome', array( $this, 'samsun_welcome_screen' ) );
	}

	/**
	 * Adds an admin notice upon successful activation.
	 * @since 1.8.2.4
	 */
	public function samsun_activation_admin_notice() {
		global $pagenow;

		if ( is_admin() && ('themes.php' == $pagenow) && isset( $_GET['activated'] ) ) {
			add_action( 'admin_notices', array( $this, 'samsun_welcome_admin_notice' ), 99 );
		}
	}

	/**
	 * Display an admin notice linking to the welcome screen
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_admin_notice() {
		?>
			<div class="updated notice is-dismissible">
				<p><?php echo sprintf( esc_html__( 'Welcome! Thank you for choosing Samsun! To fully take advantage of the best our theme can offer please make sure you visit our %swelcome page%s.', 'samsun' ), '<a href="' . esc_url( admin_url( 'themes.php?page=samsun-welcome' ) ) . '">', '</a>' ); ?></p>
				<p><a href="<?php echo esc_url( admin_url( 'themes.php?page=samsun-welcome' ) ); ?>" class="button" style="text-decoration: none;"><?php _e( 'Get started with Samsun', 'samsun' ); ?></a></p>
			</div>
		<?php
	}

	/**
	 * Load welcome screen css and javascript
	 * @since  1.8.2.4
	 */
	public function samsun_welcome_style_and_scripts( $hook_suffix ) {

		if ( 'appearance_page_samsun-welcome' == $hook_suffix ) {
			wp_enqueue_style( 'samsun-welcome-screen-css', get_template_directory_uri() . '/inc/admin/welcome-screen/css/welcome.css' );
			wp_enqueue_script( 'samsun-welcome-screen-js', get_template_directory_uri() . '/inc/admin/welcome-screen/js/welcome.js', array('jquery') );

			global $samsun_required_actions;

			$nr_actions_required = 0;

			/* get number of required actions */
			if( get_option('samsun_show_required_actions') ):
				$samsun_show_required_actions = get_option('samsun_show_required_actions');
			else:
				$samsun_show_required_actions = array();
			endif;

			if( !empty($samsun_required_actions) ):
				foreach( $samsun_required_actions as $samsun_required_action_value ):
					if(( !isset( $samsun_required_action_value['check'] ) || ( isset( $samsun_required_action_value['check'] ) && ( $samsun_required_action_value['check'] == false ) ) ) && ((isset($samsun_show_required_actions[$samsun_required_action_value['id']]) && ($samsun_show_required_actions[$samsun_required_action_value['id']] == true)) || !isset($samsun_show_required_actions[$samsun_required_action_value['id']]) )) :
						$nr_actions_required++;
					endif;
				endforeach;
			endif;

			wp_localize_script( 'samsun-welcome-screen-js', 'samsunLiteWelcomeScreenObject', array(
				'nr_actions_required' => $nr_actions_required,
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'template_directory' => get_template_directory_uri(),
				'no_required_actions_text' => __( 'Hooray! There are no recomended actions for you right now.','samsun' )
			) );
		}
	}

	/**
	 * Load scripts for customizer page
	 * @since  1.8.2.4
	 */
	public function samsun_welcome_scripts_for_customizer() {

		wp_enqueue_style( 'samsun-welcome-screen-customizer-css', get_template_directory_uri() . '/inc/admin/welcome-screen/css/welcome_customizer.css' );
		wp_enqueue_script( 'samsun-welcome-screen-customizer-js', get_template_directory_uri() . '/inc/admin/welcome-screen/js/welcome_customizer.js', array('jquery'), '20120206', true );

		global $samsun_required_actions;

		$nr_actions_required = 0;

		/* get number of required actions */
		if( get_option('samsun_show_required_actions') ):
			$samsun_show_required_actions = get_option('samsun_show_required_actions');
		else:
			$samsun_show_required_actions = array();
		endif;

		if( !empty($samsun_required_actions) ):
			foreach( $samsun_required_actions as $samsun_required_action_value ):
				if(( !isset( $samsun_required_action_value['check'] ) || ( isset( $samsun_required_action_value['check'] ) && ( $samsun_required_action_value['check'] == false ) ) ) && ((isset($samsun_show_required_actions[$samsun_required_action_value['id']]) && ($samsun_show_required_actions[$samsun_required_action_value['id']] == true)) || !isset($samsun_show_required_actions[$samsun_required_action_value['id']]) )) :
					$nr_actions_required++;
				endif;
			endforeach;
		endif;

		wp_localize_script( 'samsun-welcome-screen-customizer-js', 'samsunLiteWelcomeScreenCustomizerObject', array(
			'nr_actions_required' => $nr_actions_required,
			'aboutpage' => esc_url( admin_url( 'themes.php?page=samsun-welcome#actions_required' ) ),
			'customizerpage' => esc_url( admin_url( 'customize.php#actions_required' ) ),
			'themeinfo' => __('View Theme Info','samsun'),
		) );
	}

	/**
	 * Dismiss required actions
	 * @since 1.8.2.4
	 */
	public function samsun_dismiss_required_action_callback() {

		global $samsun_required_actions;

		$samsun_dismiss_id = (isset($_GET['dismiss_id'])) ? $_GET['dismiss_id'] : 0;

		echo $samsun_dismiss_id; /* this is needed and it's the id of the dismissable required action */

		if( !empty($samsun_dismiss_id) ):

			/* if the option exists, update the record for the specified id */
			if( get_option('samsun_show_required_actions') ):

				$samsun_show_required_actions = get_option('samsun_show_required_actions');

				$samsun_show_required_actions[$samsun_dismiss_id] = false;

				update_option( 'samsun_show_required_actions',$samsun_show_required_actions );

			/* create the new option,with false for the specified id */
			else:

				$samsun_show_required_actions_new = array();

				if( !empty($samsun_required_actions) ):

					foreach( $samsun_required_actions as $samsun_required_action ):

						if( $samsun_required_action['id'] == $samsun_dismiss_id ):
							$samsun_show_required_actions_new[$samsun_required_action['id']] = false;
						else:
							$samsun_show_required_actions_new[$samsun_required_action['id']] = true;
						endif;

					endforeach;

				update_option( 'samsun_show_required_actions', $samsun_show_required_actions_new );

				endif;

			endif;

		endif;

		die(); // this is required to return a proper result
	}


	/**
	 * Welcome screen content
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_screen() {

		?>

		<ul class="samsun-nav-tabs" role="tablist">
			<li role="presentation" class="active"><a href="#getting_started" aria-controls="getting_started" role="tab" data-toggle="tab"><?php esc_html_e( 'Getting started','samsun'); ?></a></li>
			<li role="presentation" class="samsun-w-red-tab"><a href="#actions_required" aria-controls="actions_required" role="tab" data-toggle="tab"><?php esc_html_e( 'Actions recomended','samsun'); ?></a></li>
			<?php if ( defined("ILLDY_COMPANION") ) { ?>
				<li role="presentation"><a href="#demo_content" aria-controls="demo_content" role="tab" data-toggle="tab"><?php esc_html_e( 'Demo Content','samsun'); ?></a></li>
			<?php } ?>
			<li role="presentation"><a href="#github" aria-controls="github" role="tab" data-toggle="tab"><?php esc_html_e( 'Contribute','samsun'); ?></a></li>
			<li role="presentation"><a href="#changelog" aria-controls="changelog" role="tab" data-toggle="tab"><?php esc_html_e( 'Changelog','samsun'); ?></a></li>
		</ul>

		<div class="samsun-tab-content">

			<?php
			/**
			 * @hooked samsun_welcome_getting_started - 10
			 * @hooked samsun_welcome_actions_required - 20
			 * @hooked samsun_welcome_child_themes - 30
			 * @hooked samsun_welcome_github - 40
			 * @hooked samsun_welcome_changelog - 50
			 */
			do_action( 'samsun_welcome' ); ?>

		</div>
		<?php
	}

	/**
	 * Getting started
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_getting_started() {
		require_once( get_template_directory() . '/inc/admin/welcome-screen/sections/getting-started.php' );
	}

	/**
	 * Actions required
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_actions_required() {
		require_once( get_template_directory() . '/inc/admin/welcome-screen/sections/actions-required.php' );
	}

	/**
	 * Contribute
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_github() {
		require_once( get_template_directory() . '/inc/admin/welcome-screen/sections/github.php' );
	}

	/**
	 * Changelog
	 * @since 1.8.2.4
	 */
	public function samsun_welcome_changelog() {
		require_once( get_template_directory() . '/inc/admin/welcome-screen/sections/changelog.php' );
	}
}

new samsun_Welcome();
