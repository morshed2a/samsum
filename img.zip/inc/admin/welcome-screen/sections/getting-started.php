<?php
/**
 * Getting started template
 */

$customizer_url = wp_customize_url() ;
?>

<div id="getting_started" class="samsun-tab-pane active">

	<div class="samsun-tab-pane-center">

		<h1 class="samsun-welcome-title"><?php _e('Welcome to Samsun!', 'samsun'); ?> <?php if( !empty($samsun_lite['Version']) ): ?> <sup id="samsun-theme-version"><?php echo esc_attr( $samsun_lite['Version'] ); ?> </sup><?php endif; ?></h1>

		<p><?php esc_html_e( 'Our most popular free one page WordPress theme, Samsun!','samsun'); ?></p>
		<p><?php esc_html_e( 'We want to make sure you have the best experience using Samsun and that is why we gathered here all the necessary information for you. We hope you will enjoy using Samsun, as much as we enjoy creating great products.', 'samsun' ); ?>

	</div>

	<hr />

	<div class="samsun-tab-pane-center">

		<h1><?php esc_html_e( 'Getting started', 'samsun' ); ?></h1>

		<h4><?php esc_html_e( 'Customize everything in a single place.' ,'samsun' ); ?></h4>
		<p><?php esc_html_e( 'Using the WordPress Customizer you can easily customize every aspect of the theme.', 'samsun' ); ?></p>
		<p><a href="<?php echo esc_url( $customizer_url ); ?>" class="button button-primary"><?php esc_html_e( 'Go to Customizer', 'samsun' ); ?></a></p>

	</div>

	<hr />

</div>
