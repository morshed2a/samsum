<?php
/**
 * Changelog
 */

$samsun = wp_get_theme( 'samsun' );

?>
<div class="samsun-tab-pane" id="changelog">

	<div class="samsun-tab-pane-center">
	
		<h1>Samsun <?php if( !empty($samsun['Version']) ): ?> <sup id="samsun-theme-version"><?php echo esc_attr( $samsun['Version'] ); ?> </sup><?php endif; ?></h1>

	</div>

	<?php
	WP_Filesystem();
	global $wp_filesystem;
	$samsun_changelog = $wp_filesystem->get_contents( get_template_directory().'/CHANGELOG.txt' );
	$samsun_changelog_lines = explode(PHP_EOL, $samsun_changelog);
	foreach($samsun_changelog_lines as $samsun_changelog_line){
		if(substr( $samsun_changelog_line, 0, 3 ) === "###"){
			echo '<hr /><h1>'.substr($samsun_changelog_line,3).'</h1>';
		} else {
			echo $samsun_changelog_line,'<br/>';
		}
	}

	?>
	
</div>