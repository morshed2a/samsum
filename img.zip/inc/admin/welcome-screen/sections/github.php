<?php
/**
 * Github
 */
?>

<div id="github" class="samsun-tab-pane">

	<h1><?php esc_html_e( 'How can I contribute?', 'samsun' ); ?></h1>

	<hr/>

	<div class="samsun-tab-pane-half samsun-tab-pane-first-half">
		<p><strong><?php esc_html_e( 'Found a bug? Want to contribute with a fix or create a new feature?','samsun'); ?></strong></p>

		<p><?php esc_html_e( 'GitHub is the place to go!','samsun' ); ?></p>

		<p>
			<a href="<?php echo esc_url( 'https://github.com/puikinsh/samsun' ); ?>" class="github-button button button-primary"><?php esc_html_e( 'Samsun on GitHub', 'samsun' ); ?></a>
		</p>
		<hr>
	</div>

	<div class="samsun-tab-pane-half">
		<p><strong><?php esc_html_e( 'Are you a polyglot? Want to translate samsun into your own language?', 'samsun' ); ?></strong></p>

		<p><?php esc_html_e( 'Get involved at WordPress.org.', 'samsun' ); ?></p>

		<p>
			<a href="<?php echo esc_url( 'https://translate.wordpress.org/projects/wp-themes/samsun' ); ?>" class="translate-button button button-primary"><?php _e( 'Translate Samsun', 'samsun' ); ?></a>
		</p>
		<hr>
	</div>

	<div>
		<h4><?php esc_html_e( 'Are you enjoying samsun?', 'samsun' ); ?></h4>

		<p class="review-link"><?php echo sprintf( esc_html__( 'Rate our theme on %sWordPress.org%s. We\'d really appreciate it!', 'samsun' ), '<a href="https://wordpress.org/themes/samsun/">', '</a>' ); ?></p>

		<p><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span></p>
	</div>

</div>
