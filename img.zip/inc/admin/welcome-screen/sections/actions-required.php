<?php
/**
 * Actions required
 */
?>

<div id="actions_required" class="samsun-tab-pane">

    <h1><?php esc_html_e( 'Actions recommend to make this theme look like in the demo.' ,'samsun' ); ?></h1>

    <!-- NEWS -->
    <hr />

	<?php
	global $samsun_required_actions;

	if( !empty($samsun_required_actions) ):

		/* samsun_show_required_actions is an array of true/false for each required action that was dismissed */
		$samsun_show_required_actions = get_option("samsun_show_required_actions");
		$action_number = 1;
		foreach( $samsun_required_actions as $samsun_required_action_key => $samsun_required_action_value ):
			if(@$samsun_show_required_actions[$samsun_required_action_value['id']] === false) continue;
			if(@$samsun_required_action_value['check']) continue;
			?>
			<div class="samsun-action-required-box">
				<span class="dashicons dashicons-no-alt samsun-dismiss-required-action" id="<?php echo $samsun_required_action_value['id']; ?>"></span>
				<h4><?php echo $action_number; ?>. <?php if( !empty($samsun_required_action_value['title']) ): echo $samsun_required_action_value['title']; endif; ?></h4>
				<p><?php if( !empty($samsun_required_action_value['description']) ): echo $samsun_required_action_value['description']; endif; ?></p>
				<?php
					if( !empty($samsun_required_action_value['plugin_slug']) ):
						?><p><a href="<?php echo esc_url( wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin='.$samsun_required_action_value['plugin_slug'] ), 'install-plugin_'.$samsun_required_action_value['plugin_slug'] ) ); ?>" class="button button-primary"><?php if( !empty($samsun_required_action_value['title']) ): echo $samsun_required_action_value['title']; endif; ?></a></p><?php
					endif;
				?>

				<hr />
			</div>
			<?php
			$action_number ++;
		endforeach;
	endif;

	$nr_actions_required = 0;

	/* get number of required actions */
	if( get_option('samsun_show_required_actions') ):
		$samsun_show_required_actions = get_option('samsun_show_required_actions');
	else:
		$samsun_show_required_actions = array();
	endif;

	if( !empty($samsun_required_actions) ):
		foreach( $samsun_required_actions as $samsun_required_action_value ):
			if(( !isset( $samsun_required_action_value['check'] ) || ( isset( $samsun_required_action_value['check'] ) && ( $samsun_required_action_value['check'] == false ) ) ) && ((isset($samsun_show_required_actions[$samsun_required_action_value['id']]) && ($samsun_show_required_actions[$samsun_required_action_value['id']] == true)) || !isset($samsun_show_required_actions[$samsun_required_action_value['id']]) )) :
				$nr_actions_required++;
			endif;
		endforeach;
	endif;

	if( $nr_actions_required == 0 ):
		echo '<p>'.__( 'Hooray! There are no required actions for you right now.','samsun' ).'</p>';
	endif;
	?>

</div>
