jQuery(document).ready(function() {
    var samsun_aboutpage = samsunLiteWelcomeScreenCustomizerObject.aboutpage;
    var samsun_nr_actions_required = samsunLiteWelcomeScreenCustomizerObject.nr_actions_required;

    /* Number of required actions */
    if ((typeof samsun_aboutpage !== 'undefined') && (typeof samsun_nr_actions_required !== 'undefined') && (samsun_nr_actions_required != '0') && _wpCustomizeSettings.theme.active && _wpCustomizeSettings.theme.stylesheet == 'samsun' ) {
        jQuery('#accordion-section-themes .accordion-section-title').append('<a href="' + samsun_aboutpage + '"><span class="samsun-actions-count">' + samsun_nr_actions_required + '</span></a>');
    }

});
