<?php
/**
 * Initialize the custom Meta Boxes. 
 */
add_action( 'admin_init', 'custom_meta_boxes' );

/**
 * Meta Boxes dw code.
 *
 * You can find all the available option types in dw-theme-options.php.
 *
 * @return    void
 * @since     2.0
 */
function custom_meta_boxes() {
  
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $my_meta_box = array(
    'id'          => 'meta_box',
    'title'       => __( 'Meta Box', 'theme-text-domain' ),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      
      array(
        'label'       => __( 'Add Gallery', 'theme-text-domain' ),
        'id'          => 'dw_conditions',
        'type'        => 'tab'
      ),
      array(
        'label'       => __( 'Show Gallery', 'theme-text-domain' ),
        'id'          => 'dw_show_gallery',
        'type'        => 'on-off',
        'desc'        => sprintf( __( 'Shows the Gallery when set to %s.', 'theme-text-domain' ), '<code>on</code>' ),
        'std'         => 'off'
      ),
      array(
        'label'       => '',
        'id'          => 'dw_textblock',
        'type'        => 'textblock',
        'desc'        => __( 'Congratulations, you created a gallery!', 'theme-text-domain' ),
        'operator'    => 'and',
        'condition'   => 'dw_show_gallery:is(on),dw_gallery:not()'
      ),
      array(
        'label'       => __( 'Gallery', 'theme-text-domain' ),
        'id'          => 'dw_gallery',
        'type'        => 'gallery',
        'desc'        => sprintf( __( 'This is a Gallery option type. It displays when %s.', 'theme-text-domain' ), '<code>dw_show_gallery:is(on)</code>' ),
        'condition'   => 'dw_show_gallery:is(on)'
      ),
      array(
        'label'       => __( 'More Options Meta Box', 'theme-text-domain' ),
        'id'          => 'fd_more_options',
        'type'        => 'tab'
      ),array(
        'label'       => __( 'Image Upload', 'theme-text-domain' ),
        'id'          => 'mata_image',
		'std'         => 'http://localhost/wp/wp_f/wp-content/themes/Samsun/images/page-title.jpg',
        'type'        => 'upload',
        'desc'        => __( 'This is a fd Text field.', 'theme-text-domain' )
      ),array(
        'label'       => __( 'Title Header', 'theme-text-domain' ),
        'id'          => 'mata_title',
        'type'        => 'text',
        'desc'        => __( 'Please Add Title Header', 'theme-text-domain' )
      ),array(
        'label'       => __( 'Title Header Description', 'theme-text-domain' ),
        'id'          => 'mata_description',
        'type'        => 'textarea-simple',
        'desc'        => __( 'Please Add Title Header Description ', 'theme-text-domain' )
      )
    )
  );
  //page meta box 
  $page_meta_box = array(
    'id'          => 'meta_box',
    'title'       => __( 'Meta Box', 'theme-text-domain' ),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      
      array(
        'label'       => __( 'Add Gallery', 'theme-text-domain' ),
        'id'          => 'pdw_conditions',
        'type'        => 'tab'
      ),
      array(
        'label'       => __( 'Show Gallery', 'theme-text-domain' ),
        'id'          => 'pdw_show_gallery',
        'type'        => 'on-off',
        'desc'        => sprintf( __( 'Shows the Gallery when set to %s.', 'theme-text-domain' ), '<code>on</code>' ),
        'std'         => 'off'
      ),
      array(
        'label'       => '',
        'id'          => 'pdw_textblock',
        'type'        => 'textblock',
        'desc'        => __( 'Congratulations, you created a gallery!', 'theme-text-domain' ),
        'operator'    => 'and',
        'condition'   => 'pdw_show_gallery:is(on),pdw_gallery:not()'
      ),
      array(
        'label'       => __( 'Gallery', 'theme-text-domain' ),
        'id'          => 'pdw_gallery',
        'type'        => 'gallery',
        'desc'        => sprintf( __( 'This is a Gallery option type. It displays when %s.', 'theme-text-domain' ), '<code>pdw_show_gallery:is(on)</code>' ),
        'condition'   => 'pdw_show_gallery:is(on)'
      ),
      array(
        'label'       => __( 'More Options Meta Box', 'theme-text-domain' ),
        'id'          => 'fd_more_options',
        'type'        => 'tab'
      ),array(
        'label'       => __( 'Image Upload', 'theme-text-domain' ),
        'id'          => 'pmata_image',
		'std'         => 'http://localhost/wp/wp_f/wp-content/themes/Samsun/images/page-title.jpg',
        'type'        => 'upload',
        'desc'        => __( 'This is a fd Text field.', 'theme-text-domain' )
      ),array(
        'label'       => __( 'Title Header', 'theme-text-domain' ),
        'id'          => 'pmata_title',
        'type'        => 'text',
        'desc'        => __( 'Please Add Title Header', 'theme-text-domain' )
      ),array(
        'label'       => __( 'Title Header Description', 'theme-text-domain' ),
        'id'          => 'pmata_description',
        'type'        => 'textarea-simple',
        'desc'        => __( 'Please Add Title Header Description ', 'theme-text-domain' )
      )
    )
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $my_meta_box );
if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $page_meta_box );

}


