<?php
/**
 * Initialize the custom Theme Options.
 */
add_action( 'init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 *
 * @return    void
 * @since     2.0
 */
function custom_theme_options() {

  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;

  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $site_url = get_stylesheet_directory_uri();
  $admin_url = admin_url();
  $custom_settings = array( 
    'contextual_help' => array( 
      'content'       => array( 
        array(
          'id'        => 'all_header_change',
          'title'     => __( 'Header', 'theme-text-domain' ),
          'content'   => '<p>' . __( 'Help content goes here!', 'theme-text-domain' ) . '</p>'
        )
      ),
      'sidebar'       => '<p>' . __( 'Sidebar content goes here!', 'theme-text-domain' ) . '</p>'
    ),
    'sections'        => array( 
      array(
        'id'          => 'option_types',
        'title'       => __( 'Header', 'theme-text-domain' )
      )
        ,array(
        'id'          => 'option_types_5',
        'title'       => __( 'Slider', 'theme-text-domain' )
      ),
        array(
        'id'          => 'option_types_2',
        'title'       => __( 'Quotation Text', 'theme-text-domain' )
      ),
	 array(
        'id'          => 'option_types_3',
        'title'       => __( 'Who We Are', 'theme-text-domain' )
      )
	  ,array(
        'id'          => 'option_types_4',
        'title'       => __( 'Service', 'theme-text-domain' )
      ),array(
        'id'          => 'option_types_6',
        'title'       => __( 'Our Work', 'theme-text-domain' )
      ),array(
        'id'          => 'option_types_7',
        'title'       => __( 'Quotation Text-2', 'theme-text-domain' )
      ),array(
        'id'          => 'option_types_8',
        'title'       => __( 'Our Business', 'theme-text-domain' )
      )
    ),
    'settings'        => array( 
      array(
        'id'          => 'logo',
        'label'       => __( 'Upload Logo', 'theme-text-domain' ),
        'desc'        => sprintf( __( 'Please Upload Your Logo.', 'theme-text-domain' ), '<code>ot-upload-attachment-id</code>' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'option_types',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'phone_number',
        'label'       => __( 'Phone Number', 'theme-text-domain' ),
        'desc'        => sprintf( __( 'Please Write Your Phone Number.', 'theme-text-domain' ), '<code>ot-upload-attachment-id</code>' ),
        'std'         => '+88 01916 829 396',
        'type'        => 'text',
        'section'     => 'option_types',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
		  
		  
		  //quotation text design
		  
      array(
        'id'          => 'quotation_text_title',
        'label'       => __( '<h2 class="front_page_upload">Quotation Text</h2>', 'theme-text-domain' ),
        'std'         => 'Theres huge space beetween creativity and imagination',
        'type'        => 'text',
        'section'     => 'option_types_2',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),array(
        'id'          => 'quotation_text_writer',
        'label'       => __( ' Quotation Text Writer Name.', 'theme-text-domain' ),
        'std'         => 'Mark Simmons, Nett Media',
        'type'        => 'text',
        'section'     => 'option_types_2',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'quotation_bg_color',
        'label'       => __( 'Quotation Text Bacground Color', 'theme-text-domain' ),
        'std'         => '#1bac91',
        'type'        => 'colorpicker',
        'section'     => 'option_types_2',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'front_quotation',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'quotation_icon',
        'label'       => __( 'Quotation Text Icon', 'theme-text-domain' ),
        'std'         => 'icon-coffee icon-10x',
        'type'        => 'text',
        'section'     => 'option_types_2',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'front_quotation',
        'condition'   => '',
        'operator'    => 'and'
      ),
      
	  // Who We Are page design
		
      array(
        'id'          => 'who_we_are_title',
        'label'       => __( '<h2 class="front_page_upload">Who We Are Title</h2>', 'theme-text-domain' ),
        'std'         => 'Who We Are',
        'type'        => 'text',
        'section'     => 'option_types_3',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'who_we_are_title',
        'condition'   => '',
        'operator'    => 'and'
      ),
        array(
        'id'          => 'who_we_are_sub_title',
        'label'       => __( '<h2 class="front_page_upload">Who We Are Sub Title</h2>', 'theme-text-domain' ),
        'std'         => 'We live with <strong>creativity</strong>',
        'type'        => 'text',
        'section'     => 'option_types_3',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'who_we_are_title',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'who_we_are_description',
        'label'       => __( 'Who We Are Descrption', 'theme-text-domain' ),
        'std'         => 'Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica, li pronunciation e li plu commun vocabules. Omnicos directe al desirabilite de un nov lingua franca: On refusa continuar payar custosi traductores. ',
        'type'        => 'text',
        'section'     => 'option_types_3',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'who_we_are_image',
        'label'       => __( 'Upload Image', 'theme-text-domain' ),
        'std'         => ''.$site_url.'/img/icons/creativity.png',
        'type'        => 'upload',
        'section'     => 'option_types_3',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
        array(
		'id'          => 'who_we_are_people',
		'label'       => __( '<h2 class="front_page_upload">Add Your team People.</h2>', 'option-tree-theme' ),
		
		'std'         => '',
		'type'        => 'list-item',
		'rows'        => '',
		'post_type'   => '',
		'section'     => 'option_types_3',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		'settings'    => array(
					array(
						'id'        => 'imgt',
						'label'        => 'Upload Profile Image',
						'desc'        => 'Upload Profile Image size 150px*150px',
						'std'        => '',
						'type'        => 'upload',
					),array(
						'id'        => 'namet',
						'label'        => 'Name',
						'std'        => '',
                                                'type'        => 'text',
					)
					,array(
						'id'        => 'designationt',
						'label'        => 'Add you designation',
						'std'        => '',
						'type'        => 'text',
					)

				)
	),
     
	  
	  //Service design
	
      array(
		'id'          => 'service',
		'label'       => __( '<h2 class="front_page_upload">Add Your team People.</h2>', 'option-tree-theme' ),
		
		'std'         => '',
		'type'        => 'list-item',
		'rows'        => '',
		'post_type'   => '',
		'section'     => 'option_types_4',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		'settings'    => array(
					array(
						'id'        => 'imgs',
						'label'        => 'Upload Profile Image',
						'desc'        => 'Upload Profile Image size 150px*150px',
						'std'        => '',
						'type'        => 'upload',
					),array(
						'id'        => 'descriptions',
						'label'        => 'Service Description',
						'std'        => '',
                                                'type'        => 'text',
					)
					

				)
	),
	  //slider
	  
	array(
		'id'          => 'front_slider',
		'label'       => __( 'Front Slider', 'option-tree-theme' ),
		
		'std'         => '',
		'type'        => 'list-item',
		'rows'        => '',
		'post_type'   => '',
		'section'     => 'option_types_5',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		'settings'    => array(
					array(
						'id'        => 'slider_img_upload',
						'label'        => 'Upload Your slider Image',
						'desc'        => 'description',
						'std'        => '',
						'type'        => 'upload',
					),array(
						'id'        => 'front_slider_Description',
						'label'        => 'Slider Description',
						'std'        => '',
                                                'desc'      => 'Please Write more then 85 characters',
						'type'        => 'textarea-simple',
					)
					,array(
						'id'        => 'front_slider_link',
						'label'        => 'Please add link',
						'std'        => '',
						'type'        => 'text',
					)

				)
	),
        //Our Work
        array(
		'id'          => 'our_work_tite',
		'label'       => __( '<h2 class="front_page_upload">Add Our Work Title.</h2>', 'option-tree-theme' ),
		'std'         => '',
		'type'        => 'text',
		'rows'        => '',
		'post_type'   => '',
		'section'     => 'option_types_6',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		),
        array(
		'id'          => 'add_portfolio_link',
		'label'       => __( '<h2 class="add_portfoli_text">Please Click This Link For Add Portfoli Name</h2><a href="'.$admin_url.'/edit-tags.php?taxonomy=portfolio"><h2 class="add_portfolio_link">Add Portfoli Name</h2></a>', 'option-tree-theme' ),
		'std'         => '',
		'type'        => 'textblock-titled',
		'rows'        => '',
                //'desc'        => 'Please Click This Link For Add Portfoli Name',
		'post_type'   => '',
		'section'     => 'option_types_6',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		),
        array(
		'id'          => 'our_work_portfolio',
		'label'       => __( '<h2 class="front_page_upload">Add Your Portfolio.</h2>', 'option-tree-theme' ),
		
		'std'         => '',
		'type'        => 'list-item',
		'rows'        => '',
		'post_type'   => '',
		'section'     => 'option_types_6',
		'taxonomy'    => '',
		'min_max_step'=> '',
		'class'       => '',
		'condition'   => '',
		'operator'    => 'and',
		'settings'    => array(
					array(
						'id'        => 'portfolio_name',
						'label'        => 'Select portfolio Name',
						'desc'        => 'Please Select Your Portfolio Name <a href="'.$admin_url.'edit-tags.php?taxonomy=portfolio"><h2 class="add_portfolio_link_1">Add Portfoli Name</h2></a>',
						'std'        => '',
                                                'type'        => 'taxonomy-select',
						'rows'        => '',
                                                'post_type'   => '',
                                                'section'     => 'option_types_6',
                                                'taxonomy'    => 'portfolio',
                                                'min_max_step'=> '',
                                                'class'       => '',
                                                'condition'   => '',
                                                'operator'    => 'and',
					),
					array(
						'id'        => 'portfolio_img',
						'label'        => 'Upload portfolio Image',
						'desc'        => 'Upload Profile Image size 800px * 625px',
						'std'        => '',
						'type'        => 'upload',
					),
					array(
						'id'        => 'portfolio_featured_image',
						'label'        => 'Upload portfolio Featured image',
						'desc'        => 'Upload Profile Image size 400px * 300px',
						'std'        => '',
						'type'        => 'upload',
					),array(
						'id'        => 'portfolio_descriptions',
						'label'        => 'Portfolio Description',
						'std'        => '',
                                                'type'        => 'text',
					)
                
					

				)
	),
        	  
		  //quotation text design -2
		  
      array(
        'id'          => 'quotation_text_title',
        'label'       => __( '<h2 class="front_page_upload">Quotation Text</h2>', 'theme-text-domain' ),
        'std'         => 'We are an established and trusted web agency with a reputation for commitment and high integrity ',
        'type'        => 'text',
        'section'     => 'option_types_7',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'quotation_bg_image',
        'label'       => __( 'Quotation Text Bacground Image', 'theme-text-domain' ),
        'std'         => ''.$site_url.'/img/bg/bg-3.jpg',
        'type'        => 'upload',
        'section'     => 'option_types_7',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'front_quotation_2',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'quotation_icon_2',
        'label'       => __( 'Quotation Text Icon', 'theme-text-domain' ),
        'std'         => 'icon-rocket icon-10x',
        'type'        => 'text',
        'section'     => 'option_types_7',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'front_quotation',
        'condition'   => '',
        'operator'    => 'and'
      ),
     
	
	
	  
        
     
      
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}