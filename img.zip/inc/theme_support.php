<?php 

/**
 * Register Samsun widget areas.
 *
 * @since Samsun 1.0
 */

/*	
	========================
	THEME SUPPORT OPTIONS
	========================
*/

/*	
	========================
		End THEME SUPPORT OPTIONS
	========================
*/
//strat top news widgets
function samsun_widgets_init() {
	//require get_template_directory() . '/widgets.php';
	//register_widget( 'Topnews_Ephemera_Widget' );

	register_sidebar( array(
		'name'          => __( 'Design Wave Fashion Front Page', 'samsun' ),
		'id'            => 'design-wave-fashion',
		'description'   => __( 'Add your Design Wave Fashion on front page', 'samsun' ),
		'before_widget' => '<div class="col-md-12 design-header">',
		'after_widget'  => '</div>',
		'before_title'  => '<p><strong>',
		'after_title'   => '</strong></p>',
	) );
	register_sidebar( array(
		'name'          => __( 'Left Sidebar', 'samsun' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Additional sidebar that appears on the left.', 'samsun' ),
		'before_widget' => '<div class="col-md-4 footer-sideber">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Widget Area', 'samsun' ),
		'id'            => 'sidebar-footer',
		'description'   => __( 'Appears in the footer section of the site.', 'samsun' ),
		'before_widget' => '<div class="col-md-4 footer-sideber">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'samsun_widgets_init' );

function new_excerpt_more($more) {
    global $post;
    return ' <a class="moretag btn btn-primary" href="'. get_permalink($post->ID) . '">Read More »</a>'; //Change to suit your needs
}
 
add_filter( 'excerpt_more', 'new_excerpt_more' );

/**
 * Filter the except length to 20 characters.
 *
 * @param int $length Excerpt length.
 * @return int (Maybe) modified excerpt length.
 */
//function wpdocs_custom_excerpt_length( $length ) {
//    return 60;
//}
//add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );
//set character limit on the_content() and the_excerpt()
//Change the Default Excerpt Length
function custom_excerpt_length( $length ) {
	return 90;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
//title limit word
function short_title($after = '', $length) {
   $samsun_title = explode(' ', get_the_title(), $length);
   if (count($samsun_title)>=$length) {
       array_pop($samsun_title);
       $samsun_title = implode(" ",$samsun_title). $after;
   } else {
       $samsun_title = implode(" ",$samsun_title);
   }
       return $samsun_title;
}

//multi post thumbails

