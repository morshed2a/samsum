<?php

/*
	
@package Samsun
	
	========================
		ADMIN ENQUEUE FUNCTIONS
	========================
*/

//font theme css script

function samsun_style_nscripts(){
	
        wp_enqueue_style('bootstrap-css', get_template_directory_uri() .'/css/bootstrap.min.css', array(), '1.0', 'all' );
		wp_enqueue_style('bootstrap-responsive', get_template_directory_uri() .'/css/bootstrap-responsive.css', array(), '1.0', 'all');
        wp_enqueue_style('font-awesome', get_template_directory_uri() .'/css/font-awesome.css', array(), '1.0', 'all');
        wp_enqueue_style('font-awesome-ie7', get_template_directory_uri() .'/css/font-awesome-ie7.css', array(), '1.0', 'all');
        wp_enqueue_style('animate', get_template_directory_uri() .'/css/animate.css', array(), '1.0', 'all');
        wp_enqueue_style('overwrite', get_template_directory_uri() .'/css/overwrite.css', array(), '1.0', 'all');
        wp_enqueue_style('prettyPhoto', get_template_directory_uri() .'/css/prettyPhoto.css', array(), '1.0', 'all');
        wp_enqueue_style('flexslider', get_template_directory_uri() .'/css/flexslider.css', array(), '1.0', 'all');
        
        wp_enqueue_style('default-css', get_template_directory_uri() .'/color/default.css', array(), '1.0', 'all' );

	
	
	wp_enqueue_script('bootstrap-js', get_template_directory_uri() .'/js/bootstrap.min.js', array('jquery'), '1.9.1', true );
	//wp_enqueue_script('bootstrap.min-js', get_template_directory_uri() .'/js/jquery.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('scrollTo-js', get_template_directory_uri() .'/js/jquery.scrollTo.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('nav-js', get_template_directory_uri() .'/js/jquery.nav.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('localscroll-js', get_template_directory_uri() .'/js/jquery.localscroll-1.2.7-min.js', array('jquery'), '1.2.7', true );
        wp_enqueue_script('flexslider-min-js', get_template_directory_uri() .'/plugins/flexslider/jquery.flexslider-min.js', array('jquery'), '1.0.0', true ); 
        wp_enqueue_script('flexslider-js', get_template_directory_uri() .'/plugins/flexslider/flexslider.config.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('prettyPhoto-js', get_template_directory_uri() .'/js/jquery.prettyPhoto.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('isotope-js', get_template_directory_uri() .'/js/isotope.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('flexslider-js', get_template_directory_uri() .'/js/jquery.flexslider.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('inview-js', get_template_directory_uri() .'/js/inview.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('animate-js', get_template_directory_uri() .'/js/animate.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('validate-js', get_template_directory_uri() .'/js/validate.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('custom-js', get_template_directory_uri() .'/js/custom.js', array('jquery'), '1.0.0', true );
        wp_enqueue_script('contactform-js', get_template_directory_uri() .'/contactform/contactform.js', array('jquery'), '1.0.0', true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
}
add_action('wp_enqueue_scripts', 'samsun_style_nscripts');


function wpb_add_google_fonts() {

wp_enqueue_style( 'wpb-google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700', true); 
wp_enqueue_style( 'wpb-google-fonts', 'https://fonts.googleapis.com/css?family=Baloo+Bhaina&amp;subset=latin-ext,oriya,vietnamese', false ); 
}

add_action( 'wp_enqueue_scripts', 'wpb_add_google_fonts' );












